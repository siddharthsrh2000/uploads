package com.bookings.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookings.VO.ResponseTemplateVO;
import com.bookings.bookingDTOs.BookingDTO;
import com.bookings.service.BookingService;

@RestController
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	

	//my use
	@PostMapping("/booking/users/{userId}/myuse/{coachId}")
	public ResponseTemplateVO myUseAppointment(@PathVariable Integer userId,@PathVariable Integer coachId,@RequestBody BookingDTO bookingDTO) {
		return bookingService.myUseAppointment(userId,coachId,bookingDTO);
	}
	
	
	@PostMapping("/booking/users/{userId}/coaches/{coachId}")
	public String bookAppointment(@PathVariable Integer userId,@PathVariable Integer coachId,@RequestBody BookingDTO bookingDTO) {
		return bookingService.bookAppointment(userId,coachId,bookingDTO);
	}
	
	@PutMapping("/booking/{bookingId}")
	public String rescheduleAppointment(@PathVariable Integer bookingId,@RequestBody BookingDTO bookingDTO) {
		return bookingService.rescheduleAppointment(bookingId,bookingDTO);
	}
	
	@DeleteMapping("/booking/{bookingId}")
	public String cancelAppointment(@PathVariable Integer bookingId) {
		return bookingService.cancelAppointment(bookingId);
	}
}
