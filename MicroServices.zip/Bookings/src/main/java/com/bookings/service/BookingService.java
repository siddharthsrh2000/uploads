package com.bookings.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bookings.VO.Coaches;
import com.bookings.VO.ResponseTemplateVO;
import com.bookings.VO.Users;
import com.bookings.bookingDTOs.BookingDTO;
import com.bookings.entity.Bookings;
import com.bookings.repository.BookingRepository;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private RestTemplate restTemplate;

	// my use
	public ResponseTemplateVO myUseAppointment(Integer userId, Integer coachId, BookingDTO bookingDTO) {
		try {
			ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
			Users users = restTemplate.getForObject("http://USER-SERVICE/users/check/" + userId, Users.class);
			Coaches coaches = restTemplate.getForObject("http://COACH-SERVICE/coaches/check/" + coachId,Coaches.class);
			
			//Users users = restTemplate.getForObject("http://localhost:9001/users/check/" + userId, Users.class);
			//Coaches coaches = restTemplate.getForObject("http://localhost:9002/coaches/check/" + coachId,Coaches.class);
			
			
			responseTemplateVO.setUsers(users);
			responseTemplateVO.setCoaches(coaches);
			return responseTemplateVO;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	public String bookAppointment(Integer userId, Integer coachId, BookingDTO bookingDTO) {
		try {
			Users users = restTemplate.getForObject("http://USER-SERVICE/users/check/" + userId, Users.class);
			Coaches coaches = restTemplate.getForObject("http://COACH-SERVICE/coaches/check/" + coachId,Coaches.class);
			
			
			//Users users = restTemplate.getForObject("http://localhost:9001/users/check/" + userId, Users.class);
			//Coaches coaches = restTemplate.getForObject("http://localhost:9002/coaches/check/" + coachId,Coaches.class);
			
			
			
			
			if (users != null && coaches != null) {
				System.out.println("inside came");
				bookingDTO.setUserId(userId);
				bookingDTO.setCoachId(coachId);
				Bookings bookings = BookingDTO.convertDTOtoEntity(bookingDTO);
				bookingRepository.save(bookings);
				return "hai " + bookings.getBookingId();
			}
			return null;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return e.getMessage();
		}
	}

	public String rescheduleAppointment(Integer bookingId, BookingDTO bookingDTO) {
		try {
			if (checkAppointment(bookingId)) {
				Bookings bookings=bookingRepository.findById(bookingId).get();
				bookings.setDateOfAppointment(bookingDTO.getDateOfAppointment());
				bookings.setSlot(bookingDTO.getSlot());
				bookingRepository.save(bookings);
				return "OK";
			}
			return "booking id not found";
		} 
		catch (Exception e) {
			return e.getMessage();
		}
	}

	private boolean checkAppointment(Integer bookingId) {
		try {
			Optional<Bookings> bookings = bookingRepository.findById(bookingId);
			if (bookings.isPresent()) {
				return true;
			}
			return false;
		} 
		catch (Exception e) {
			return false;
		}
	}

	public String cancelAppointment(Integer bookingId) {
		try {
			if(checkAppointment(bookingId)) {
				bookingRepository.deleteById(bookingId);
				return "OK";
			}
			return "booking id not found";
		}
		catch (Exception e) {
			return e.getMessage();
		}
	}

}
