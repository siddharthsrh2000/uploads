package com.bookings.VO;

import com.bookings.entity.Bookings;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseTemplateVO {
	
	private Users users;
	private Coaches coaches;
	private Bookings bookings;
}
