package com.bookings.bookingDTOs;

import java.time.LocalDate;

import com.bookings.entity.Bookings;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BookingDTO {
		private Integer bookingId;
		private Integer userId;
		private Integer coachId;
		private LocalDate dateOfAppointment;
		private String slot;
		
		public static Bookings convertDTOtoEntity(BookingDTO dto) {
			
			Bookings bookings = new Bookings();
			bookings.setBookingId(dto.getBookingId());
			bookings.setUserId(dto.getUserId());
			bookings.setCoachId(dto.getCoachId());
			bookings.setDateOfAppointment(dto.getDateOfAppointment());
			bookings.setSlot(dto.getSlot());
			return bookings;
	    	
	    }
		
		
}

