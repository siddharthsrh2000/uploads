package com.bookings.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bookings.entity.Bookings;

@Repository
public interface BookingRepository extends JpaRepository<Bookings, Integer>{

	
	@Query(value = "SELECT * FROM Bookings b WHERE b.coachid = ", nativeQuery = true)
	List<Bookings> showCoachSchedule(Integer id);
	
}