package com.coaches.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coaches.entity.Coaches;

public interface CoachRepository extends JpaRepository<Coaches, Integer> {

}
