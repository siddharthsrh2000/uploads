package com.coaches.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coaches.coachException.CoachExceptions;
import com.coaches.entity.Coaches;
import com.coaches.service.CoachService;

@RestController
@RequestMapping("/coaches")
public class CoachController {

	@Autowired
	private CoachService coachService;

	@PostMapping("")
	public String createCoach(@RequestBody Coaches coaches) {
		return coachService.createCoach(coaches);
	}

	@GetMapping("/login/{coachId}/{password}")
	public Boolean loginCoach(@PathVariable Integer coachId, @PathVariable String password) {
		return coachService.loginCoach(coachId, password);
	}

	@GetMapping("/{coachId}")
	public String getCoachProfile(@PathVariable Integer coachId) {
		return coachService.getCoachProfile(coachId);
	}

	@GetMapping("/all")
	public List<Coaches> showAllCoaches() {
		return coachService.showAllCoaches();
	}

	//my use
	@GetMapping("/check/{coachId}")
	public Coaches checkCoach(@PathVariable Integer coachId) throws CoachExceptions {
		return coachService.checkCoach(coachId);
	}

	@GetMapping("/bool/{coachId}")
	public Boolean boolCoach(@PathVariable Integer coachId) throws CoachExceptions {
		return coachService.boolCoach(coachId);
	}

}
