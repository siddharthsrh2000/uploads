package com.coaches.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coaches.coachException.CoachExceptions;
import com.coaches.entity.Coaches;
import com.coaches.repository.CoachRepository;


@Service
public class CoachService {

	@Autowired
	private CoachRepository coachRepository;

	public String createCoach(Coaches coaches) {
		try {
			coachRepository.save(coaches);
			return "OK "+coaches.getCoachId();
		}
		catch (Exception e) {
			return CoachExceptions.creationError(e.getMessage());
		}
	}

	public Boolean loginCoach(Integer coachId, String password) {
		try {
			Coaches coaches=coachRepository.findById(coachId).get();
			if(coaches.getCoachId().compareTo(coachId)==0) {
				if(coaches.getPassword().compareTo(password)==0) {
					return true;
				}
			}
			return false;
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	public String getCoachProfile(Integer coachId) {
		try {
			Optional<Coaches> coaches=coachRepository.findById(coachId);
			if(coaches.isPresent()) {
				return coaches.toString();
			}
			else {
				return "no coach with the entered coachid : "+coachId;
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return CoachExceptions.gettingCoachError();
		}
	}

	public List<Coaches> showAllCoaches() {
		try {
			List<Coaches> listOfCoaches=coachRepository.findAll();
			return listOfCoaches;
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	//my use
	public Coaches checkCoach(Integer coachId) {
		try {
			Optional<Coaches> coaches=coachRepository.findById(coachId);
			if(coaches.isPresent()) {
				return coaches.get();
			}
			return null;
		}
		catch (Exception e) {
			return null;
		}
	}

	
	
	public Boolean boolCoach(Integer coachId) {
		try {
			Optional<Coaches> coaches=coachRepository.findById(coachId);
			if(coaches.isPresent()) {
				return true;
			}
			return false;
		}
		catch (Exception e) {
			return false;
		}
	}

}
