package com.coaches.coachException;

@SuppressWarnings("all")
public class CoachExceptions extends Exception{

	public static String creationError(String message) {
		return "OK "+message;
	}

	public static String gettingCoachError() {
		return "Some error ocuured while fetching coach details";
	}
	

}
