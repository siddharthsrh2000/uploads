package com.users.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.users.UserExceptions.UserExceptions;
import com.users.entity.Users;
import com.users.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public String createUser(Users u) throws UserExceptions {
		try {
			userRepository.save(u);
			return "hai " + u.getUserId();
		} catch (Exception e) {
			return UserExceptions.userCreationException();
		}
	}

	public String getUserProfile(Integer userId) throws UserExceptions {
		try {
			return userRepository.findById(userId).get().toString();
		} catch (Exception e) {
			return UserExceptions.userNotFoundException();
		}
	}

	public Boolean loginUser(Integer userId, String password) {
		try {
			Optional<Users> users = userRepository.findById(userId);
			if (users.isPresent()) {
				if (users.get().getUserId().compareTo(userId) == 0) {
					if (users.get().getPassword().compareTo(password) == 0) {
						return true;
					}
				} 
				else {
					return false;
				}
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		return false;
	}

	public Users checkUser(Integer userId) {
		try {
			Users users=userRepository.findById(userId).get();
			if(users.getUserId()!=null) {
				System.out.println("inside users check");
				return users;
			}
			return null;
		}
		catch (Exception e) {
			return null;
		}
	}

	public Boolean boolUser(Integer userId) {
		try {
			Optional<Users> users=userRepository.findById(userId);
			if(users.isPresent()) {
				return true;
			}
			return false;
		}
		catch (Exception e) {
			return false;
		}
	}

}
