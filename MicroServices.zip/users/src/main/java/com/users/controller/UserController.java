package com.users.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.users.UserExceptions.UserExceptions;
import com.users.entity.Users;
import com.users.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("")
	public String createUser(@RequestBody Users users) throws UserExceptions {
		return userService.createUser(users);
	}

	@GetMapping("/{userId}")
	public String getUserProfile(@PathVariable Integer userId) throws UserExceptions {
		return userService.getUserProfile(userId);
	}

	@GetMapping("/login/{userId}/{password}")
	public Boolean loginUser(@PathVariable Integer userId, @PathVariable String password) {
		return userService.loginUser(userId, password);
	}

	@GetMapping("/bool/{userId}")
	public Boolean boolUser(@PathVariable Integer userId) throws UserExceptions {
		return userService.boolUser(userId);
	}

	// My use
	@GetMapping("/check/{userId}")
	public Users checkUser(@PathVariable Integer userId) throws UserExceptions {
		return userService.checkUser(userId);
	}

}
