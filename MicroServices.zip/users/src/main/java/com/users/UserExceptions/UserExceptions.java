package com.users.UserExceptions;

import com.users.entity.Users;

@SuppressWarnings("all")
public class UserExceptions extends Exception {

	public static String userCreationException() {
		return "Send all details properly";
	}

	public static String userNotFoundException() {
		return "entered userid is not found";
	}
	

}
